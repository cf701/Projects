#include <cstdlib>
#include <iostream>

using namespace std;
// function declarations
// returnType functionName( parameterList );
void PrintLine( );
void Print4Lines( );
void PrintLines( int n );
void PrintLines ( int lines, int numberChars );
void PrintLines ( int lines, int numberChars, char c );

int Factorial ( int ); // n! = n * ( n-1 ) * (n-2) * ... * 2 * 1

int main(int argc, char *argv[])
{
    // use/call a function
    // functionName ( argumentList)
    PrintLines( 10, 50, '?' );
    PrintLines( 5, 12 );
    int factorial4 = Factorial ( 4 );
    cout << "Factorial ( 4 ) = " << factorial4 << endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}

// function implementation
void PrintLine( )
{
  cout << "*****************************"<< endl;    
}
void Print4Lines( ) 
{
    PrintLine( );
    PrintLine( );
    PrintLine( );
    PrintLine( ); 
}

void PrintLines( int n )
{
     for (int i = 0; i < n; i++)
      PrintLine( );
}

void PrintLines( int lines, int numberChars )
{
  /*
  for ( int i = 0; i < lines; i++)
  {
      // print a line
      for ( int j = 0; j < numberChars; j++)
      {
       cout << "*";
      }
      cout << endl;
  }*/
  PrintLines( lines, numberChars, '*' );
}

void PrintLines( int lines, int numberChars, char c )
{
  for ( int i = 0; i < lines; i++)
  {
      // print a line
      for ( int j = 0; j < numberChars; j++)
      {
       cout << c;
      }
      cout << endl;
  }
}

int Factorial ( int n )
{
 int result = 1;
 for ( int i = 1; i <= n; i++ )
     result *= 1;
 return result;
}

