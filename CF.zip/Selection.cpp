#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    
    int grade;
    cout << "Please enter a grade > ";
    cin >> grade;
    
    //keep asking user for a grade if grade is invalid
    while( grade > 100 || grade < 0 )
    {
           // ask user for a grade
           cout << "Please enter a grade > ";
           cin >> grade;
    if( cin.fail( ))
         {
           //break;
           cin.clear(); // restore the input stream to a good state
           cin.ignore( 100 , '\n' ); 
         }
    }
    
    
    
    if(grade > 100 || grade < 0)
       cout << "Illegal Grade!" << endl;
    else if(grade >= 90)
       cout << "A" << endl;
    else if(grade >= 80)
       cout << "B" << endl;
    else if (grade >= 70)
       cout << "C" << endl;
    else if (grade >= 60)
       cout << "D"<< endl;
    else if (grade >= 0)
       cout << "F" << endl;
    system("PAUSE");
    return EXIT_SUCCESS;
    
    
}
